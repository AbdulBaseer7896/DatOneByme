// routes/fileRoutes.js

const express = require('express');
const router = express.Router();
const fileController = require('../controllers/fileController');
const upload = require('../config/multerConfig'); // Multer configuration for file uploads
const auth = require('../middleware/auth');

router.use(auth)

// Route to upload a file and save its information
router.get('/download/:filename', fileController.downloadJsonFile);
router.post('/upload/:dataSessionId', upload.single('file'), fileController.uploadJsonFile);

module.exports = router;

// models/DataSession.js

const mongoose = require('mongoose');

const DataSessionSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true,
  },
  proxy: {
    type: String,
    required: true,
    unique: true,
  },
  fileName: {
    type: String,
    default: null,
  },
}, {
    timestamps: true,
});

DataSessionSchema.virtual('File', {
  ref: 'File',
  localField: '_id', 
  foreignField: 'file',
  justOne: true  
});

// Make sure virtuals are included when converting to JSON
DataSessionSchema.set('toObject', { virtuals: true });
DataSessionSchema.set('toJSON', { virtuals: true });

const DataSession = mongoose.model('dataSession', DataSessionSchema);

module.exports = DataSession;
